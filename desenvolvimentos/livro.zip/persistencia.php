<?php

function salvarDados(array $dados, string $nomeArquivo) {
    
}